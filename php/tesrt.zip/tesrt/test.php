<form action="a.php" method="GET">
<input type="text" name="name">
<input type="submit">
</form>